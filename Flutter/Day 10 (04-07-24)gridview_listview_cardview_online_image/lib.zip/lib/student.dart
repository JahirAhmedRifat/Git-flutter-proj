class Student{
String? name;
String? details;
String? photo;

Student(this.name, this.details, this.photo);

}